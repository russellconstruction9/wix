import React from 'react';
import { motion } from 'framer-motion';
import { Wrench, Truck, BarChart, Cog, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Services = () => {
  const services = [
    {
      icon: <Wrench className="h-12 w-12 text-blue-600" />,
      title: 'Equipment Repairs & Training',
      description: 'Expert diagnosis and repair of spray foam equipment. Comprehensive training for your team on maintenance and troubleshooting.',
      features: [
        'On-site emergency repairs',
        'Preventive maintenance programs',
        'Equipment operation training',
        'Troubleshooting workshops'
      ]
    },
    {
      icon: <Truck className="h-12 w-12 text-blue-600" />,
      title: 'Custom Rig Building',
      description: 'Custom-designed spray foam rigs built to your specifications. Maximize efficiency with purpose-built mobile spray foam units.',
      features: [
        'Custom rig design',
        'Mobile unit optimization',
        'Equipment integration',
        'Safety system installation'
      ]
    },
    {
      icon: <BarChart className="h-12 w-12 text-blue-600" />,
      title: 'Business Growth Support',
      description: 'Strategic consulting to help your spray foam business reach its full potential. From marketing to operations optimization.',
      features: [
        'Market analysis',
        'Growth strategy development',
        'Marketing plan creation',
        'Operations optimization'
      ]
    },
    {
      icon: <Cog className="h-12 w-12 text-blue-600" />,
      title: 'Custom App Development',
      description: 'Tailored software solutions to streamline your spray foam business operations and improve efficiency.',
      features: [
        'Job estimation tools',
        'Project management systems',
        'Customer relationship management',
        'Mobile apps for field teams'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-blue-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Comprehensive Services for Spray Foam Contractors
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              From equipment repairs to business growth strategies, we provide the expertise you need to succeed.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-lg p-8"
              >
                <div className="mb-6">{service.icon}</div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h2>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-700">
                      <ArrowRight className="h-5 w-5 text-blue-600 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/contact"
                  className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium"
                >
                  Learn more
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Elevate Your Business?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Let's discuss how our services can help you achieve your business goals.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-3 border-2 border-blue-400 text-base font-medium rounded-md text-blue-400 hover:bg-blue-400 hover:text-white transition-colors md:text-lg"
          >
            Schedule a Consultation
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;